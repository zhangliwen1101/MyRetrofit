package com.guogavin.retorifit.demo;

/**
 * Created by gavinguo on 7/8/2015.
 */
public class Constants {

    public final static String BASE_URL = "http://1.mirror3.sinaapp.com/gavin";

}
